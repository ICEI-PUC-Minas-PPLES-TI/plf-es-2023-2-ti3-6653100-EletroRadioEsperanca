<?php
date_default_timezone_set('America/Sao_Paulo');
date_default_timezone_set('America/Sao_Paulo');
define('SHEEP_URL', 'localhost/lojaFinalTeste');
define('SHEEP_HOST','localhost');
define('SHEEP_USER','root');
define('SHEEP_SENHA','');
define('SHEEP_BD','loja07');
define('SITENAME', "Nome do site");
define('SITEDESC', "Nome do site" );
define('SITELOGO',"Nome do site" );
define('SITEICONE', "Nome do site" );
define('FONE', "Nome do site" );
define('CNPJ', "Nome do site" );
define('CELULAR', "Nome do site" );
define('EMAIL', "Nome do site" );
define('ATENDIMENTO', "Nome do site");
define('ENDERECO', "Nome do site" );
define('NUMERO', "Nome do site" );
define('CEP', "Nome do site" );
define('CIDADE',"Nome do site" );
define('ESTADO', "Nome do site");
define('FACEBOOK', "Nome do site");
define('INSTAGRAM', "Nome do site" );
define('TWITTER', "Nome do site" );
define('YOUTUBE', "Nome do site" );
define('GOOGLE_TITULO', "Nome do site" );
define('GOOGLE_DESC', "Nome do site" );
define('GOOGLE_TAGS', "Nome do site" );
define('GOOGLE_VERIFY', "Nome do site" );
define('FACEBOOK_PIXEL', "Nome do site");
define('LINKS_PADROES', "Nome do site" );
define('DESATIVAR_MOUSE', "Nome do site" );
define('RODAPE', "Nome do site" );
define('EMAIL_PHPMAILER_SECURE', 'tls');
define('EMAIL_PHPMAILER_CHARSET', 'utf-8');
define('EMAIL_PHPMAILER_PASS', '');
define('EMAIL_PHPMAILER_PORT', "587");
define('EMAIL_PHPMAILER_QUEM_ENVIA', "");
define('EMAIL_PHPMAILER_QUEM_ENVIA_NOME', SITENAME);

require_once('includes.php');

?>


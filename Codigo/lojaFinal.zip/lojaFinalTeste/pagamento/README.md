# shopping-cart-stripe

Sistema simples, criado apenas para fazer um carrinho de compras com checkout com Stripe para pagamentos onlines.

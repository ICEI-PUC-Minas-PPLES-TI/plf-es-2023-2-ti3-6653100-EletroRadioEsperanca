<div class="row">
  <div class="col-md-12">
    <div class="card mb-0">
      <div class="card-body">
        <ul class="nav nav-pills" style="margin:5px; float:right;">
          <li class="nav-item">
            <a class="nav-link active" href="addProduto.php">Cadastrar Produto </a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="editarProduto.php">Editar Produto </a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="../login/sistemaFuncionario.php">Voltar </a>
          </li>
        </ul>
        <ul class="nav nav-pills">

          <li class="nav-item">
            <a class="nav-link active" href="../index.php" target="_blank">LOJA</a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</div>